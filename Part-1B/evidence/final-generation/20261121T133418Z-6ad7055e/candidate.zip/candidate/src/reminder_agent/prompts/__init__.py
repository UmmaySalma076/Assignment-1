"""Versioned model prompts."""
