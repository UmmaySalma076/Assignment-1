"""HTTP API boundary."""
