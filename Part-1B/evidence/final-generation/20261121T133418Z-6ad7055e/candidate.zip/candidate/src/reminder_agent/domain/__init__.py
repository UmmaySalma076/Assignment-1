"""Deterministic reminder domain rules."""
